import colors
from object import Object

class Entity(Object):
    def __init__(self, x, y, dir, color, speed):
        super().__init__(x, y, color, "mob")
        self._speed = speed
        self._direction = dir    # top: -2, right: 1, down: 2, left: -1
        self._current_time = 0

    def update_pos(self, key=None):
        if key:
            if self._direction + key != 0:
                self._direction = key

        self._x += self._direction if abs(self._direction) == 1 else 0
        if self._direction == 2:
            self._y += 1
        elif self._direction == -2:
            self._y -= 1

    def get_speed(self):
        return 1/self._speed

    def is_move(self, dt):
        self._current_time += dt
        if self._current_time > (1/self._speed):
            self._current_time = 0
            return True
        return False

class Fireball(Entity):
    def __init__(self, x, y, dir):
        super().__init__(x, y, dir, colors.purple, 5)
