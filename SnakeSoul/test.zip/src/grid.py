import pygame
import colors

class Cell:
    def __init__(self, type, color, text=None):
        self.__type = type
        self.__color = color
        self.__text = text

    def __str__(self):
        return self.__type

    def get_type(self):
        return self.__type

    def set_type(self, type):
        self.__type = type
    
    def get_color(self):
        return self.__color
    
    def set_color(self, color):
        self.__color = color

    def get_text(self):
        return self.__text

    def set_text(self, text):
        self.__text = text

class Grid:
    def __init__(self, xOffset, yOffset, width, height, dim, font):
        self.__xOffset = xOffset
        self.__yOffset = yOffset
        self.__cellWidth = (width-xOffset)/dim[0]
        self.__cellHeight = (height-yOffset)/dim[1]
        self.__dim = dim
        self.__cells = []
        self.__font = font

        for _ in range(dim[0]):
            temp = []
            for _ in range(dim[1]):
                cell = Cell("none", None)
                temp.append(cell)
            self.__cells.append(temp)

    def draw(self, screen):
        for i in range(self.__dim[0]):
            for j in range(self.__dim[1]):
                x = self.__xOffset + i*self.__cellWidth
                y = self.__yOffset + j*self.__cellHeight
                cell_color = self.__cells[i][j].get_color()
                cell_text = self.__cells[i][j].get_text()
                if cell_color:
                    pygame.draw.rect(screen, self.__cells[i][j].get_color(), [x, y, self.__cellWidth, self.__cellHeight])
                pygame.draw.rect(screen, colors.gray, [x, y, self.__cellWidth, self.__cellHeight], 1)
                if cell_text:
                    cell_text = self.__font.render(cell_text, True, colors.white)
                    screen.blit(cell_text, cell_text.get_rect(topleft=(x, y)))

    def addObject(self, x, y, type, color, text=None):
        self.__cells[x][y].set_type(type)
        self.__cells[x][y].set_color(color)
        self.__cells[x][y].set_text(text)

    def getShape(self):
        return self.__dim

    def reset(self):
        for i in range(self.__dim[0]):
            for j in range(self.__dim[1]):
                self.__cells[i][j].set_type("none")
                self.__cells[i][j].set_color(None)
                self.__cells[i][j].set_text(None)

    def checkBounderies(self, pos):
        return True if pos[0] >= self.__dim[0] or pos[0] < 0 or pos[1] >= self.__dim[1] or pos[1] < 0 else False
        
