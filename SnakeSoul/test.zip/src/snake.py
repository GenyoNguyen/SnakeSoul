import colors
from object import Object
from entity import Entity

class Snake(Entity):
    MAX_SPEED = 10
    def __init__(self, x, y, lives):
        super().__init__(x, y, dir=1, color=colors.green, speed=2)
        self.__snake = [Object(x, y, colors.green, "snake")]
        self.__lives = lives

    def move(self):
        self.__snake[0].set_color(colors.green)
        self.__snake.pop()
        self.__snake.insert(0, Object(self._x, self._y, colors.lime, "snake"))

    def grow(self):
        self.__snake[0].set_color(colors.green)
        self.__snake.insert(0, Object(self._x, self._y, colors.lime, "snake"))
        self.__update_speed()

    def decay(self, index):
        if index == -1:
            index += len(self.__snake)
        if index == 0:
            self.__lives -= 1
            return len(self.__snake)
        else:
            deleted = len(self.__snake) - index
            del self.__snake[index:]
            self.__update_speed()
            return deleted

    def gain_live(self):
        self.__lives = min(self.__lives + 1, 3)

    def lose_live(self):
        self.__lives -= 1

    def self_collide(self):
        index = self.collide(self.get_segments_pos()[1:])
        if index != -1:
            self.decay(index)
            return True
        return False

    def is_dead(self):
        return self.__lives == 0

    def __update_speed(self):
        self._speed = min(2*(len(self.__snake)//5) + 2, Snake.MAX_SPEED)

    def getSegments(self):
        return self.__snake

    def getDirection(self):
        return self._direction

    def get_segments_pos(self):
        return [(s._x, s._y) for s in self.__snake]

    def get_head(self):
        return self._x, self._y

    def get_lives(self):
        return self.__lives
