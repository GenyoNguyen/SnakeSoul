class Object:
    def __init__(self, x, y, color, type):
        self._x = x
        self._y = y
        self._color = color
        self._type = type

    def get_x(self):
        return self._x
    
    def get_y(self):
        return self._y
    
    def get_pos(self):
        return self._x, self._y

    def get_color(self):
        return self._color

    def set_color(self, color):
        self._color = color

    def get_type(self):
        return self._type
    
    def collide(self, poses):
        for i in range(len(poses)):
            if (self._x, self._y) == poses[i]:
                return i
        return -1
