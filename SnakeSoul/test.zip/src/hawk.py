import random
from entity import Fireball
from apples import Apple, GoldenApple, PoisonApple

class Hawk:
    MAX_HEALTH = 3000
    def __init__(self, grid_size):
        self.__health = Hawk.MAX_HEALTH
        self.__mobs = []
        self.__apples = []
        self.__grid_size = grid_size

    def update(self, dt):
        for m in self.__mobs:
            if m.is_move(dt):
                m.update_pos()

    def spawn_fireball(self):
        choice = random.randrange(4)
        if choice == 0:
            self.__mobs.append(Fireball(0, random.randrange(self.__grid_size[1]), 1))
        elif choice == 1:
            self.__mobs.append(Fireball(self.__grid_size[0]-1, random.randrange(self.__grid_size[1]), -1))
        elif choice == 2:
            self.__mobs.append(Fireball(random.randrange(self.__grid_size[0]), 0, 2))
        elif choice == 3:
            self.__mobs.append(Fireball(random.randrange(self.__grid_size[0]), self.__grid_size[1]-1, -2))

    def __spawn_apple(self, type, init_time):
        if type == "apple":
            return Apple(random.randint(0, self.__grid_size[0]-1), random.randint(0, self.__grid_size[1]-1))
        if type == "golden_apple":
            return GoldenApple(random.randint(0, self.__grid_size[0]-1), random.randint(0, self.__grid_size[1]-1), 5, init_time)
        return PoisonApple(random.randint(0, self.__grid_size[0]-1), random.randint(0, self.__grid_size[1]-1), 5, init_time)

    def spawn_apple(self, type, banned_pos, init_time):
        apple = self.__spawn_apple(type, init_time)
        while apple.get_pos() in banned_pos+[a.get_pos() for a in self.__apples]:
            apple = self.__spawn_apple(type, init_time)
        self.__apples.append(apple)

    def reset_mob(self):
        self.__mobs = []

    def heal(self, value):
        self.__health = min(self.__health + value, Hawk.MAX_HEALTH)

    def damage(self, value):
        self.__health = max(self.__health - value, 0)

    def is_dead(self):
        return self.__health == 0

    def get_health(self):
        return self.__health

    def get_mobs(self):
        return self.__mobs

    def get_apples(self):
        return self.__apples

    def get_apple_pos(self):
        return [a.get_pos() for a in self.__apples]

    def get_mob_pos(self):
        return [m.get_pos() for m in self.__mobs]
    
    def remove_mob(self, m):
        self.__mobs.remove(m)

    def remove_apple(self, a):
        self.__apples.remove(a)

    def pop_apple(self, index):
        type = self.__apples[index].get_type()
        self.__apples.pop(index)
        return type
