from .game import main
